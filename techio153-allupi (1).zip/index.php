<?php
header("Location: ./techio153/");
exit();
?>