function getAddressFields() {
  return {
    name: ($("#name").val() || "").trim(),
    number: ($("#number").val() || "").trim(),
    pin: ($("#pin").val() || "").trim(),
    flat: ($("#flat").val() || "").trim(),
    area: ($("#area").val() || "").trim(),
    city: ($("#city").val() || "").trim(),
    state_id: $("#state").val(),
    state: $("#state :selected").text(),
  };
}

function goToCart(address) {
  // Agar kuch fill kiya hai toh save karega, varna khali hi aage bhej dega
  localStorage.setItem("address", JSON.stringify(address));
  window.location.href = MAIN_URL + "cart/";
}

$(document).ready(function () {
  // Button click hote hi direct aage bhejne ka code (No Form Submit, No Check)
  $("#quickSaveBtn").on("click", function (e) {
    e.preventDefault();
    const address = getAddressFields();
    goToCart(address); // Seedha cart page par redirect!
  });

  // Back button theek se kaam kare
  $("#back_btn").on("click", function () {
    history.back();
  });
});
