const JSON_URL = MAIN_URL + "data.json";
let productData = null, selectedColor = "";

function getPrimaryId() {
  const urlParams = new URLSearchParams(window.location.search);
  if(urlParams.has('id')) return urlParams.get('id');
  const path = window.location.pathname.split("/");
  // Handles dynamic URL mapping
  let idx = path.indexOf("single-products");
  if(idx !== -1 && path[idx+1]) return path[idx+1].replace('/', '');
  return "1"; // Fallback ID
}
const PRIMARY_ID = getPrimaryId();

function doAPICall(req, callback) {
  fetch(JSON_URL)
    .then(res => res.json())
    .then(data => {
      if(req.op === "get_product_details") {
        const product = data.products.find(p => String(p.id) === String(req.id) && !p.hidden);
        if (product) callback({ status: true, data: product });
        else callback({ status: false });
      }
    })
    .catch(() => callback({ status: false }));
}

function loadProductDetails(res) {
  if (res && res.status) {
    productData = res.data;
    $(".product-title").text(`${productData.name} (${productData.colors[0].color_name})`);
    updatePrice(productData.selling_price, productData.mrp, productData.wow_price);
    renderColors(productData.colors);
    renderCarousel(productData.colors[0].images);
    renderDescriptionImages(productData.description_images);
    if (productData.warranty_img) $("#warrantyImage").attr("src", productData.warranty_img);
  } else if (!res) {
    doAPICall({ op: "get_product_details", id: PRIMARY_ID }, loadProductDetails);
  } else {
    // If not found, load fallback product id 1
    if(PRIMARY_ID !== "1") {
       doAPICall({ op: "get_product_details", id: "1" }, loadProductDetails);
    } else {
       alert("Product not found");
    }
  }
}

function renderColors(colors) {
  const list = $(".color-list").empty();
  colors.forEach((c, i) => {
    const div = $(`<div class="color-item ${i === 0 ? "active" : ""}">
      <img src="${c.color_img}" style="width:100px;height:100px;border-radius:8px;object-fit:contain;">
      <p style="font-size:12px;text-align:center;">${c.color_name}</p></div>`);
    div.click(() => {
      $(".color-item").removeClass("active");
      div.addClass("active");
      selectedColor = c.color_name;
      renderCarousel(c.images);
      $(".product-title").text(`${productData.name} (${selectedColor})`);
    });
    list.append(div);
    if (i === 0) selectedColor = c.color_name;
  });
}

function renderCarousel(images) {
  const inner = $(".carousel-inner").empty(), ind = $(".carousel-indicators").empty();
  images.forEach((img, i) => {
    inner.append(`<div class="carousel-item ${i === 0 ? "active" : ""}">
      <img src="${img}" class="d-block w-100"></div>`);
    ind.append(`<button type="button" data-bs-target="#sliderX" data-bs-slide-to="${i}" class="${i === 0 ? "active" : ""}" aria-label="Slide ${i + 1}"></button>`);
  });
}

function renderDescriptionImages(images) {
  const desc = $("#description-images").empty();
  if (!images || !images.length) return desc.html("");
  images.forEach(img => desc.append(`<img src="${img}" alt="" loading="lazy" style="width:100%;">`));
}

function updatePrice(selling, mrp, wow_price) {
  function formatINR(amount) { return Number(amount).toLocaleString("en-IN"); }
  $(".price").text("₹" + formatINR(selling));
  $(".mrp").text("₹" + formatINR(mrp));
  $(".wow_price").text("₹" + formatINR(wow_price));

  let d = (100 - (selling * 100 / mrp)).toFixed(0);
  $(".discount").text((d == 100 ? 99 : d) + "%");
}

const carousel = document.getElementById("sliderX");
let hideTimeout;

function showControls() {
  if(!carousel) return;
  carousel.classList.add("carousel-show-controls");
  clearTimeout(hideTimeout);
  hideTimeout = setTimeout(() => {
    carousel.classList.remove("carousel-show-controls");
  }, 2000);
}

if(carousel) {
    carousel.addEventListener("mouseenter", showControls);
    carousel.addEventListener("mousemove", showControls);
    carousel.addEventListener("touchstart", showControls);
}

function isAddressRequired(settings) {
  const v = settings && settings.address_required;
  return !(v === false || v === 0 || v === "0" || v === "false");
}

async function loadSiteSettings() {
  try {
    const res = await fetch(MAIN_URL + "data/settings.json?t=" + Date.now(), {
      cache: "no-store",
    });
    if (res.ok) {
      const s = await res.json();
      if (s && typeof s === "object") {
        window.FK_SITE_SETTINGS = Object.assign(
          {},
          window.FK_SITE_SETTINGS || {},
          s
        );
      }
    }
  } catch (e) {}
  return window.FK_SITE_SETTINGS || {};
}

async function buyNow() {
  if (!productData) return alert("Please wait...");
  const color = productData.colors.find(c => c.color_name === selectedColor);
  const variant = { name: productData.name, color: selectedColor, mrp: productData.mrp, selling_price: productData.selling_price, img1: color.images[0] };
  localStorage.setItem("selected_verient", JSON.stringify(variant));

  const settings = await loadSiteSettings();
  const needAddress = isAddressRequired(settings);
  window.location.href = MAIN_URL + (needAddress ? "address/index.php" : "cart/");
}

function startCountdown(min, sec) {
  let t = min * 60 + sec;
  const el = document.getElementById("timer");
  if(!el) return;
  setInterval(() => {
    const m = Math.floor(t / 60);
    const s = t % 60;
    el.textContent = `${m}m ${s}s`;
    if (--t < 0) t = min * 60 + sec;
  }, 1000);
}

let similarProductsLoaded = false;

function loadSimilarProducts() {
  if (similarProductsLoaded) return; 
  similarProductsLoaded = true;

  fetch(JSON_URL)
    .then(res => res.json())
    .then(data => {
      const all = data.products.filter(p => String(p.id) !== String(PRIMARY_ID) && !p.hidden);
      const similar = all.sort(() => 0.5 - Math.random()).slice(0, 10);

      const scroll = document.getElementById("similar-scroll");
      if(!scroll) return;
      scroll.innerHTML = "";

      const count = Math.floor(Math.random() * 3) + 3;
      const bestsellerIndexes = [];
      while (bestsellerIndexes.length < count && bestsellerIndexes.length < similar.length) {
        const rand = Math.floor(Math.random() * similar.length);
        if (!bestsellerIndexes.includes(rand)) bestsellerIndexes.push(rand);
      }

      similar.forEach((p, i) => {
        const mrp = Number(p.mrp);
        const sell = Number(p.selling_price);
        let discount = mrp ? Math.round(((mrp - sell) / mrp) * 100) : 0;
        if (discount === 100) discount = 99;
        const wow = p.wow_price || (sell - 100);
        const rating = (Math.random() * (5 - 4.2) + 4.2).toFixed(1);

        const fullStars = Math.floor(rating);
        const halfStar = rating % 1 >= 0.5;
        let starsHTML = "";
        for (let j = 0; j < fullStars; j++) starsHTML += '<i class="bi bi-star-fill" style="color:#26a541;"></i>';
        if (halfStar) starsHTML += '<i class="bi bi-star-half" style="color:#26a541;"></i>';
        while (starsHTML.match(/bi-star/g)?.length < 5)
          starsHTML += '<i class="bi bi-star" style="color:#ccc;"></i>';

        const showBadge = bestsellerIndexes.includes(i);
        const badgeHTML = showBadge ? `<div class="bestseller-badge">Bestseller</div>` : "";

        const div = document.createElement("div");
        div.className = "similar-card";
        
        // FIX: URL corrected to index.php
        div.innerHTML = `
          <a href="${MAIN_URL}products/index.php?id=${p.id}" 
             style="text-decoration:none;color:inherit;position:relative;display:block;">
            <div style="position:relative;">
              ${badgeHTML}
              <img src="${p.img1}" alt="${p.name}">
            </div>
            <div style="padding:6px 8px 10px 8px;">
              <div class="similar-name">${p.name}</div>
              <div class="similar-price">
                ${discount}% 
                <span class="mrp">₹${mrp.toLocaleString("en-IN")}</span>
                <span class="sell">₹${sell.toLocaleString("en-IN")}</span>
              </div>
              <div class="similar-wow-offer">
                <img class="wow-badge" src="https://rukminim2.flixcart.com/www/114/48/promos/30/08/2023/59dc7885-72bf-4135-9099-025f074b0eb1.png?q=90" alt="WOW Offer">
                <span class="wow-price">₹${wow.toLocaleString("en-IN")}</span>
                <span class="offer-text">with offer</span>
              </div>
              <div class="similar-rating">
                <div class="rating-stars">${starsHTML}</div>
                <img src="${MAIN_URL}static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png" 
                     alt="F-Assured" style="height:14px;margin-left:6px;">
                <span style="font-size:12px;color:#555;">(${rating})</span>
              </div>
            </div>
          </a>`;
        scroll.appendChild(div);
      });
    })
    .catch(err => console.error("Similar products error:", err));
}

function loadReviews() {
  const section = document.getElementById("reviewsSection");
  const loader = document.getElementById("review-loader");
  const list = document.getElementById("review-list");
  if(!section) return;

  loader.style.display = "flex";
  loader.style.opacity = "1";
  list.innerHTML = "";

  fetch(JSON_URL)
    .then(res => res.json())
    .then(data => {
      // Find reviews matching current PID
      const allReviews = data.reviews || [];
      const reviewsData = Array.isArray(allReviews) 
          ? allReviews.filter(r => String(r.product_id) === String(PRIMARY_ID))
          : [];
      
      if (!reviewsData || reviewsData.length === 0) {
        section.remove();
        return;
      }

      loader.classList.add("hide");

      setTimeout(() => {
        loader.style.display = "none";

        reviewsData.forEach((review, i) => {
          let starsHTML = "";
          const full = Math.floor(review.rating);
          const half = review.rating % 1 >= 0.5;
          for (let j = 0; j < full; j++) starsHTML += '<i class="bi bi-star-fill" style="color:#26a541;"></i>';
          if (half) starsHTML += '<i class="bi bi-star-half" style="color:#26a541;"></i>';
          while (starsHTML.match(/bi-star/g)?.length < 5)
            starsHTML += '<i class="bi bi-star" style="color:#ccc;"></i>';

          const imagesHTML = (review.images || []).map(img => `
            <div class="reviewImageList"><img src="${img}" alt="review photo"></div>
          `).join('');

          const div = document.createElement("div");
          div.className = "reviewLoopInner mb-3 pb-3";
          div.style.borderBottom = "1px solid #eee";
          div.innerHTML = `
            <div class="d-flex align-items-center mb-1">
              <img src="${review.customer_img || 'https://rukminim2.flixcart.com/www/100/100/promos/19/07/2021/6f022137-b50a-42c2-846f-c1eb45c1dc23.png?q=90'}" style="width:40px;height:40px;border-radius:50%;object-fit:cover;">
              <h6 style="margin-left:10px;font-size:14px;">${review.author || 'Flipkart Customer'}</h6>
            </div>
            <div class="rating-stars mb-1">${starsHTML}</div>
            <p style="font-size:14px;margin-bottom:4px;color:#333;line-height:1.5;">${review.text || review.comment || ''}</p>
            <p style="font-size:12px;color:#757575;">Reviewed in India | ${review.date || 'Recently'}</p>
            <div class="mainListImg">${imagesHTML}</div>
          `;
          list.appendChild(div);

          setTimeout(() => div.classList.add("show"), 150 * i);
        });

        initReviewGallery();
      }, 500);
    })
    .catch(err => {
      console.error("Review Load Error:", err);
      section.remove();
    });
}

function initReviewGallery() {
  const popup = document.getElementById("imagePopup");
  if(!popup) return;
  const popupImage = document.getElementById("popupImage");
  const closeBtn = document.getElementById("popupClose");
  const prevBtn = document.getElementById("popupPrev");
  const nextBtn = document.getElementById("popupNext");

  let images = [];
  let currentIndex = 0;

  function refreshImages() {
    images = Array.from(document.querySelectorAll(".reviewImageList img"));
  }

  document.body.addEventListener("click", (e) => {
    const img = e.target.closest(".reviewImageList img");
    if (img) {
      refreshImages();
      currentIndex = images.indexOf(img);
      popup.classList.add("show");
      popupImage.src = img.src;
      document.body.style.overflow = "hidden";
    }
  });

  if(prevBtn && nextBtn) {
      prevBtn.style.opacity = "1";
      nextBtn.style.opacity = "1";
      prevBtn.style.transition = "none";
      nextBtn.style.transition = "none";

      prevBtn.addEventListener("click", () => {
        if (!images.length) return;
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        popupImage.src = images[currentIndex].src;
      });

      nextBtn.addEventListener("click", () => {
        if (!images.length) return;
        currentIndex = (currentIndex + 1) % images.length;
        popupImage.src = images[currentIndex].src;
      });
  }

  if(closeBtn) closeBtn.addEventListener("click", closePopup);
  popup.addEventListener("click", (e) => {
    if (e.target === popup) closePopup();
  });

  function closePopup() {
    popup.classList.remove("show");
    document.body.style.overflow = "";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadProductDetails();
  setTimeout(loadSimilarProducts, 1000);
  setTimeout(loadReviews, 1500);

  let rv = document.getElementById("rating-value");
  if(rv) rv.innerHTML = (Math.random() * (5 - 4.5) + 4.5).toFixed(1);
  
  let rc = document.getElementById("ratingcount");
  if(rc) rc.innerHTML = `• ${Math.floor(Math.random() * (10000 - 3000 + 1)) + 3000} ratings`;

  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + 2);
  let dd = document.getElementById("delivery-date");
  if(dd) dd.innerText = deliveryDate.toLocaleString('en-US', { day: "numeric", month: "short", weekday: "short" });
  
  startCountdown(15, 10);
});