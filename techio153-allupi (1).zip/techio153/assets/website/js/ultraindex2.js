(() => {
  const list = document.getElementById("homeList");
  const loader = document.getElementById("scrollLoader");

  let page = 1;
  let loading = false;
  let ended = false;
  const itemsPerPage = 10;
  let allProducts = null;

  function isTruthyFlag(v) {
    return v === true || v === 1 || v === "1" || v === "true";
  }

  function shouldShuffleProducts() {
    const s = window.FK_SITE_SETTINGS || {};
    return s.display_mode === "random" || isTruthyFlag(s.product_shuffle);
  }

  async function loadSiteSettings() {
    // 1) Live settings.json (no cache)
    try {
      const res = await fetch(`${MAIN_URL}data/settings.json?t=${Date.now()}`, {
        cache: "no-store",
      });
      if (res.ok) {
        const s = await res.json();
        if (s && typeof s === "object") {
          window.FK_SITE_SETTINGS = Object.assign(
            {},
            window.FK_SITE_SETTINGS || {},
            s
          );
          return window.FK_SITE_SETTINGS;
        }
      }
    } catch (e) {}

    // 2) Fallback: public admin API
    try {
      const urls = [
        `${MAIN_URL}admin2/api.php?action=get_settings&t=${Date.now()}`,
        `${MAIN_URL}admin/api.php?action=get_settings&t=${Date.now()}`,
      ];
      for (const url of urls) {
        try {
          const res = await fetch(url, { cache: "no-store" });
          if (!res.ok) continue;
          const data = await res.json();
          if (data && data.success && data.settings) {
            window.FK_SITE_SETTINGS = Object.assign(
              {},
              window.FK_SITE_SETTINGS || {},
              data.settings
            );
            return window.FK_SITE_SETTINGS;
          }
        } catch (e) {}
      }
    } catch (e) {}

    return window.FK_SITE_SETTINGS || {};
  }

  function prepareProducts(products) {
    const list = Array.isArray(products)
      ? products.filter((p) => !p || !p.hidden).slice()
      : [];
    if (shouldShuffleProducts() && list.length > 1) {
      for (let i = list.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [list[i], list[j]] = [list[j], list[i]];
      }
    }
    return list;
  }

  function generateStars(rating) {
    let starsHTML = "";
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5 ? 1 : 0;
    const emptyStars = 5 - fullStars - halfStar;

    for (let i = 0; i < fullStars; i++)
      starsHTML += '<i class="bi bi-star-fill"></i>';
    if (halfStar) starsHTML += '<i class="bi bi-star-half"></i>';
    for (let i = 0; i < emptyStars; i++)
      starsHTML += '<i class="bi bi-star"></i>';

    return starsHTML;
  }

  function getDeliveryDate() {
    const d = new Date();
    d.setDate(d.getDate() + Math.floor(Math.random() * 3) + 2);
    const day = d.getDate();

    let suffix = "th";
    if (day === 1 || day === 21 || day === 31) suffix = "st";
    else if (day === 2 || day === 22) suffix = "nd";
    else if (day === 3 || day === 23) suffix = "rd";

    const month = d.toLocaleString("en-IN", { month: "short" });
    return `${day}${suffix} ${month}`;
  }

  function getRandomStockTag() {
    const types = ["left", "deal"];
    const type = types[Math.floor(Math.random() * types.length)];

    if (type === "left") {
      const num = Math.floor(Math.random() * 14) + 2;
      return { text: `Only ${num} left`, color: "#b90000" };
    } else {
      const deals = [
        "Super deals",
        "Best deals",
        "Hot deal",
        "Trending",
        "Special offer",
      ];
      const deal = deals[Math.floor(Math.random() * deals.length)];
      return { text: deal, color: "#008c00" };
    }
  }

  async function fetchStoreData(forceFresh) {
    const CACHE_KEY = "fk_data_json_v2";
    const CACHE_TS = "fk_data_json_ts_v2";
    const MAX_AGE_MS = 5 * 60 * 1000;

    // Random mode: never reuse cached product order/data
    if (!forceFresh && !shouldShuffleProducts()) {
      try {
        const ts = parseInt(sessionStorage.getItem(CACHE_TS) || "0", 10);
        const raw = sessionStorage.getItem(CACHE_KEY);
        if (raw && Date.now() - ts < MAX_AGE_MS) {
          return JSON.parse(raw);
        }
      } catch (e) {}
    }

    const response = await fetch(`${MAIN_URL}data.json?t=${Date.now()}`, {
      cache: "no-store",
    });
    if (!response.ok) throw new Error("Request failed");
    const data = await response.json();
    if (!shouldShuffleProducts()) {
      try {
        sessionStorage.setItem(CACHE_KEY, JSON.stringify(data));
        sessionStorage.setItem(CACHE_TS, String(Date.now()));
      } catch (e) {}
    } else {
      try {
        sessionStorage.removeItem(CACHE_KEY);
        sessionStorage.removeItem(CACHE_TS);
      } catch (e) {}
    }
    return data;
  }

  async function loadMore() {
    if (loading || ended) return;
    loading = true;
    if (loader) loader.style.display = "block";

    try {
      if (!allProducts) {
        await loadSiteSettings();
      }
      const data = await fetchStoreData(!allProducts);
      if (!allProducts) {
        allProducts = prepareProducts(data.products);
      }
      const products = allProducts;

      const start = (page - 1) * itemsPerPage;
      const end = start + itemsPerPage;
      const currentProducts = products.slice(start, end);

      if (currentProducts.length === 0) {
        ended = true;
      } else {
        let html = "";
        currentProducts.forEach((p) => {
          let discount = Math.round(((p.mrp - p.selling_price) / p.mrp) * 100);
          if (discount === 100) discount = 99;

          let stock = getRandomStockTag();
          let stockHtml = `<div class="stock-text" style="color:${stock.color};">${stock.text}</div>`;

          // ✅ FIXED: WOW price ab selling_price dikhayega
          html += `
          <a href="${MAIN_URL}products/index.php?id=${p.id}" class="item">
              <div class="img-wrap">
                  <img src="${p.img1}" alt="${p.name}">
              </div>
              <div class="details">
                  <div class="title">${p.name}</div>
                  
                  <div class="rating-row">
                      <span class="stars">${generateStars(p.rating)}</span> 
                      <span class="count">(${p.reviews_count.toLocaleString()})</span> 
                      <img class="assured" src="https://rukminim2.flixcart.com/www/120/32/promos/25/06/2024/71af54bd-9160-41ff-81cc-c55e534dedeb.png?q=60" alt="Assured">
                  </div>
                  
                  <div class="price-row">
                      <span class="disc">↓${discount}%</span>
                      <span class="mrp">₹${p.mrp.toLocaleString(
                        "en-IN"
                      )}</span> 
                      <span class="sell">₹${p.selling_price.toLocaleString(
                        "en-IN"
                      )}</span> 
                  </div>
                  
                  <div class="wow">
                      <img src="https://rukminim2.flixcart.com/www/92/39/promos/30/08/2023/59dc7885-72bf-4135-9099-025f074b0eb1.png?q=90" alt="WOW">
                      <span class="wow-price">₹${p.selling_price.toLocaleString(
                        "en-IN"
                      )}</span>
                      <span class="wow-text">with offer</span>
                  </div>
                  
                  ${stockHtml}
                  
                  <div class="delivery">Delivery by <b>${getDeliveryDate()}</b></div>
              </div>
          </a>`;
        });

        list.insertAdjacentHTML("beforeend", html);
        page++;
      }
    } catch (err) {
      console.log("Load error:", err);
    } finally {
      loading = false;
      if (loader) loader.style.display = "none";
    }
  }

  loadMore();

  window.addEventListener(
    "scroll",
    () => {
      if (ended || loading) return;
      if (
        window.innerHeight + window.scrollY >=
        document.body.offsetHeight - 350
      ) {
        loadMore();
      }
    },
    { passive: true }
  );
})();

(() => {
  const bar = document.getElementById("dealBar");
  if (!bar) return;

  let total = (parseInt(bar.dataset.minutes, 10) || 10) * 60;
  const m = document.getElementById("dbMin");
  const s = document.getElementById("dbSec");

  function pad(n) {
    return String(n).padStart(2, "0");
  }

  const t = setInterval(() => {
    if (total <= 0) {
      clearInterval(t);
      const title = bar.querySelector(".deal-title");
      const dot = bar.querySelector(".deal-dot");
      if (title) title.textContent = "Deals Ended";
      if (dot) dot.style.background = "#ff5252";
      return;
    }

    total--;
    if (m) m.textContent = pad(Math.floor(total / 60));
    if (s) s.textContent = pad(total % 60);
  }, 1000);
})();
