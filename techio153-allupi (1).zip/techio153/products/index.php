<!DOCTYPE html>
<html lang="en-IN">
<head>
    <title>Online Shopping</title>
    
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="Keywords" content="Online Shopping - Flipkart">
    <meta name="Description" content="Online Shopping - Flipkart">
    <meta property="og:title" content="We are Here To Help You">
    <meta name="theme-color" content="#2874f0" id="themeColor">
    <meta name="viewport" content="width=device-width,minimum-scale=1,user-scalable=no">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../assets/website/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/website/css/ultra.css">
    <link rel="stylesheet" href="../assets/website/css/custom.css">
    
    <script>
        var loc = window.location.pathname.split('/');
        if(loc[loc.length-1] === '') loc.pop();
        if(loc[loc.length-1] && loc[loc.length-1].indexOf('.') !== -1) loc.pop();
        if(loc[loc.length-1] === 'products') loc.pop();
        var MAIN_URL = window.location.origin + loc.join('/') + '/';
    </script>
    
    <style>
        /* 🛡️ ANTI-SELECT & ANTI-DRAG CSS */
        * {
            -webkit-user-select: none !important;
            -moz-user-select: none !important;
            -ms-user-select: none !important;
            user-select: none !important;
            -webkit-user-drag: none !important;
        }
        input, textarea {
            -webkit-user-select: auto !important;
            -moz-user-select: auto !important;
            -ms-user-select: auto !important;
            user-select: auto !important;
        }

        /* ========== LOADING SCREEN (SPINNER + BLUR) ========== */
        body.loading-active {
            overflow: hidden;
        }
        .product-loader-overlay {
            position: fixed;
            inset: 0;
            z-index: 99999;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            display: flex;
            justify-content: center;
            align-items: center;
            transition: opacity 0.4s ease-out;
        }
        .product-loader-overlay.is-hidden {
            opacity: 0;
            pointer-events: none;
            visibility: hidden;
        }
        .product-loader-ring {
            width: 48px;
            height: 48px;
            border: 4px solid #e0e0e0;
            border-top: 4px solid #2874f0;
            border-radius: 50%;
            animation: ringSpin 0.8s linear infinite;
        }
        @keyframes ringSpin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Slider Fixes */
        .carousel-inner img{height:310px;object-fit:contain;background:#fff;padding:6px;display:block;margin:auto;margin-top:20px;} 
        .bestseller-badge { position: absolute; top: 0; left: 0; background: #2874f0; color: #fff; font-size: 10px; font-weight: 600; padding: 3px 6px; border-radius: 8px 0 8px 0; z-index: 10; }
        .similar-card { flex: 0 0 auto; width: 170px; background: #fff; border: 1px solid #eee; border-radius: 6px; margin-top: 5px; overflow: hidden; box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08); font-family: 'Inter', sans-serif; }
        .similar-card .sim-img { width: 100%; height: 130px; object-fit: contain; display: block; margin: 0 auto; }
        .similar-card .wow-badge, .similar-card .fa-logo { width: auto !important; object-fit: contain; background: transparent; }
        
        .color-list { display: flex; gap: 12px; overflow-x: auto; padding: 10px 5px; scrollbar-width: none; }
        .color-list::-webkit-scrollbar { display: none; }
        .color-item { flex: 0 0 auto; width: 75px; border: 2px solid #e0e0e0; border-radius: 6px; padding: 4px; cursor: pointer; text-align: center; transition: 0.2s; }
        .color-item.active { border-color: #2874f0; box-shadow: 0 2px 5px rgba(40,116,240,0.2); }
        .color-item img { width: 100%; height: 55px; object-fit: contain; border-radius: 4px; }
        .color-item p { font-size: 11px; margin: 4px 0 0 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #333; font-weight: 500;}

        .detail-heading { font-size: 16px; font-weight: 600; padding: 12px 15px; border-bottom: 1px solid #f0f0f0; margin: 0; }
        .highlights-list { padding: 15px 15px 15px 30px; margin: 0; font-size: 14px; line-height: 1.6; color: #212121; }
        .highlights-list li { padding-bottom: 8px; }
        .spec-table { width: 100%; border-collapse: collapse; font-size: 14px; margin-top: 10px; }
        .spec-table td { padding: 10px 15px; border-bottom: 1px solid #f0f0f0; }
        .spec-table td:first-child { width: 40%; color: #878787; }

        .review-images-scroll { display: flex; gap: 10px; overflow-x: auto; margin-bottom: 10px; padding-bottom: 5px; scrollbar-width: none; }
        .review-images-scroll::-webkit-scrollbar { display: none; }
        .review-thumb-box { width: 65px; height: 65px; flex-shrink: 0; border: 1px solid #e0e0e0; border-radius: 4px; overflow: hidden; cursor: pointer; }
        .review-thumb-box img { width: 100%; height: 100%; object-fit: cover; }
        .image-popup-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); z-index: 10000; flex-direction: column; justify-content: center; align-items: center; }
        .image-popup-overlay img { max-width: 100%; max-height: 80vh; object-fit: contain; }
        .popup-close { position: absolute; top: 15px; right: 20px; width: 30px; height: 30px; color: white; font-size: 35px; font-weight: bold; cursor: pointer; display: flex; justify-content: center; align-items: center; z-index: 10001;}
        .popup-close::after { content: "\00d7"; }
        
        @media(max-width:576px) {
            .similar-card { width: 160px; }
            .similar-card .sim-img { height: 120px; }
        }
    </style>
</head>
<body class="loading-active">

<!-- ========== SPINNER LOADING ========== -->
<div id="productLoader" class="product-loader-overlay">
    <div class="product-loader-ring"></div>
</div>

<!-- Header -->
<div class="container-fluid py-2" style="background-color:#fff;height:52px;position:fixed;z-index:1000;top:0;left:0;right:0;box-shadow:rgba(50,50,93,0.25) 0px 6px 12px -2px,rgba(0,0,0,0.3) 0px 3px 7px -3px;">
    <div class="row header">
        <div class="col-1"><div class="menu-icon" id="back_btn" onclick="window.history.go(-1);"><svg width="19" height="16" viewBox="0 0 19 16" xmlns="http://www.w3.org/2000/svg"><path d="M17.556 7.847H1M7.45 1L1 7.877l6.45 6.817" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg></div></div>
        <div class="col-2"><div class="menu-logo"><img alt="menu" src="../xxx/fliplpogo.png" height="30px" onclick="window.history.go(-1);"></div></div>
        <div class="col-5"></div>
        <div class="col-1"><div class="menu-icon"><svg height="30" viewBox="0 0 32 32" width="30" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M32.0012 0H0.0012207V32H32.0012V0Z"></path><path d="M15.0012 21.9999C18.8671 21.9999 22.0011 18.8659 22.0011 14.9999C22.0011 11.134 18.8671 8 15.0012 8C11.1352 8 8.00122 11.134 8.00122 14.9999C8.00122 18.8659 11.1352 21.9999 15.0012 21.9999Z" stroke="#111112" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M19.9524 19.95L24.0024 24" stroke="#111112" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg></div></div>
        <div class="col-1"><div class="menu-icon" style="margin-right:2px"><svg width="20" height="20" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M24 23H8.56185C8.32766 23 8.1009 22.9178 7.9211 22.7678C7.7413 22.6177 7.61987 22.4093 7.57797 22.1789L4.2402 3.82112C4.19831 3.5907 4.07688 3.3823 3.89708 3.23225C3.71728 3.08219 3.49052 3 3.25633 3H1" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9 28C10.3807 28 11.5 26.8807 11.5 25.5C11.5 24.1193 10.3807 23 9 23C7.61929 23 6.5 24.1193 6.5 25.5C6.5 26.8807 7.61929 28 9 28Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M24 28C25.3807 28 26.5 26.8807 26.5 25.5C26.5 24.1193 25.3807 23 24 23C22.6193 23 21.5 24.1193 21.5 25.5C21.5 26.8807 22.6193 28 24 28Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M5 8H26.8018C26.9483 8 27.0929 8.03218 27.2256 8.09425C27.3583 8.15633 27.4757 8.2468 27.5695 8.35925C27.6634 8.4717 27.7314 8.6034 27.7687 8.74504C27.8061 8.88667 27.8119 9.03478 27.7857 9.17889L26.1493 18.1789C26.1074 18.4093 25.986 18.6177 25.8062 18.7678C25.6264 18.9178 25.3996 19 25.1654 19H7" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></div></div>
        <div class="col-1"><div class="menu-icon"><a class="_3NH1qf _1R18h6"><svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.70068 9.56354C9.90982 9.56354 11.7007 7.77268 11.7007 5.56354C11.7007 3.3544 9.90982 1.56354 7.70068 1.56354C5.49154 1.56354 3.70068 3.3544 3.70068 5.56354C3.70068 7.77268 5.49154 9.56354 7.70068 9.56354Z" stroke="black" stroke-width="1.2" stroke-miterlimit="10"></path><path d="M1.63818 13.0635C2.25252 11.9993 3.1362 11.1155 4.2004 10.501C5.26461 9.88649 6.47182 9.56299 7.70068 9.56299C8.28364 9.56299 8.86172 9.63579 9.42198 9.77792C9.78986 9.87125 10.1501 9.99447 10.4989 10.1466" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M14.5877 10.5123L10.7383 14.3618L8.8136 12.437" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg></a></div></div>
    </div>
</div>

<div class="_1fhgRH mb-5 mt-5">
    
    <!-- Image Slider & Colors -->
    <div class="container p-1 card">
        <div class="container-fluid px-0 product-slider">
            <div class="love-icon"><svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#717478" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg></div>
            <div class="share-icon"><svg width="24" height="24" fill="none" viewBox="0 0 22 22"><path fill-rule="evenodd" clip-rule="evenodd" d="M13.187 2.316v4.323c-7.655 1.08-10.936 6.484-12.03 11.887 2.735-3.782 6.562-5.511 12.03-5.511v4.43l7.655-7.564-7.655-7.565Z" fill="#fff" stroke="#717478"></path></svg></div>
            
            <div id="sliderX" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators"></ol>
                <div class="carousel-inner">
                    <div class="carousel-item active"><img src="../xxx/ready.png" class="d-block w-100" alt="Loading"></div>
                </div>
            </div>
            
            <div class="color-div mt-2">
                <h4 style="font-size:14px; font-weight:600; padding-left:10px;">Color</h4>
                <div class="color-list p-2"></div>
            </div>
        </div>
    </div>
    
    <!-- Title & Pricing -->
    <div class="container-fluid p-3 mt-1 card">
        <div class="product-title" style="font-size: 16px; font-weight: 400; color: #212121; margin-bottom: 8px;">Loading...</div>
        
        <div style="display:flex;align-items:center;">
            <div class="gUuXy- _16VRIQ _1eJXd3 d-flex align-items-center gap-1" style="background:#26a541; padding:2px 6px; border-radius:4px; color:#fff;">
                <span id="rating-value" style="font-size:12px; font-weight:bold;">4.5</span>
                <i class="bi bi-star-fill" style="font-size:10px;"></i>
            </div>
            <span id="ratingcount" style="margin-left:8px;color:#878787;font-size:13px; font-weight:500;"></span>
            <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png" style="height:21px; margin-left:auto">
        </div>
        
        <div class="product-price d-flex align-items-center my-2 gap-2">
            <span class="discount" style="color:#388e3c; font-weight:700; font-size:16px;">0% off</span>
            <span class="mrp" style="color:#878787; text-decoration:line-through; font-size:16px;">000</span>
            <span class="price" style="font-size:24px; font-weight:700; color:#212121;">00</span>
        </div>
        
        <div>
            <p style="font-size:14px; margin-bottom:4px;">+ <del style="color:grey">₹99</del> Secured Packaging Free</p>
            <p style="font-size:13px; font-weight:500;">Free delivery by <span style="font-weight:700;">2 Days</span></p>
        </div>
    </div>
    
    <!-- Delivery Banner -->
    <div class="card mt-2">
        <div style="display:flex;padding:12px;gap:15px; align-items:center;">
            <div><img src="https://i.ibb.co/cK2M2f5z/truck.webp" style="width:40px"></div>
            <div>
                <p style="font-size:14px; margin:0;"><span style="font-size:15px;color:black;font-weight:700">Express</span> <span style="color:green; font-weight:600;">Free</span> <del style="color:grey">₹40</del> Delivery</p>
                <p style="font-size:13px; margin:2px 0;">Delivery by <span id="delivery-date" style="font-weight:bold;color:#212121;"></span></p>
                <p style="font-size:12px;color:grey;margin:0;">Offer ends in <span id="timer" style="color:rgba(199,0,85,1); font-weight:600;">15m 10s</span></p>
            </div>
        </div>
    </div>
    
    <!-- WOW Price Strip -->
    <div class="container-fluid mt-2 py-3" style="background-color:#fff;font-family:Arial,sans-serif;display:flex;align-items:center;padding:10px;">
        <img src="https://i.ibb.co/4MtgWPp/Wow-Deal300ppi.png" alt="Wow" style="height:35px;margin-right:15px">
        <div>
            <div style="color:#000; font-weight:bold; font-size:17px;display:inline">Get at</div>
            <span style="font-size:18px; font-weight:bold;color:rgb(0,140,0); margin-left:4px;"><span class="wow_price">₹99</span></span>
            <div style="color:#878787;font-size:11px;">With UPI Payment & More</div>
        </div>
    </div>

    <!-- Features Banner -->
    <div class="container-fluid px-3 py-3 card mt-2" style="background:#fff;">
        <div style="display:flex; align-items:center; gap:12px; padding-bottom:12px; border-bottom:1px solid #f0f0f0; margin-bottom:12px;">
            <img src="https://rukminim2.flixcart.com/www/36/36/promos/06/09/2016/c22c9fc4-0555-4460-8401-bf5c28d7ba29.png?q=90" style="width:24px; height:24px;">
            <span style="font-size:14px; font-weight:600; color:#212121;">1 YEAR BRAND WARRANTY</span>
        </div>
        <img src="https://i.ibb.co/h1HLgdM7/Screenshot-20251109-233352.jpg" style="width:100%; display:block;">
    </div>

    <!-- Highlights Section -->
    <div id="highlights-container" class="card mt-2 d-none">
        <h5 class="detail-heading">Highlights</h5>
        <ul class="highlights-list" id="product-highlights"></ul>
    </div>

    <!-- Specifications Section -->
    <div id="specs-container" class="card mt-2 d-none">
        <h5 class="detail-heading">Specifications</h5>
        <div id="product-specs"></div>
    </div>

    <!-- Similar Products -->
    <div class="similar-products-section card mt-2">
        <h5 class="detail-heading">Similar Products</h5>
        <div class="similar-scroll" id="similar-scroll">
            <div class="similar-loading">
                <div class="skeleton-card"></div><div class="skeleton-card"></div>
            </div>
        </div>
    </div>

    <!-- Full Description Images & Text -->
    <div class="container-fluid product-detail px-0 py-0 mt-2 mb-2 card">
        <h5 class="detail-heading">Product Description</h5>
        <div class="product-details p-3">
            <div id="text-description" style="font-size:14px; color:#212121; line-height:1.6; margin-bottom:15px;"></div>
            <div id="description-images"></div>
        </div>
    </div>

    <!-- Reviews Section -->
    <div class="py-3 mainReviewsOut card mb-5" id="reviewsSection">
        <div class="container">
            <h5 class="detail-heading border-0 px-0 mb-3" style="font-size:18px;">Ratings & Reviews</h5>
            <div class="review-loading" id="review-loader">
                <div class="review-skeleton"><div class="avatar"></div><div class="line medium"></div><div class="line long"></div></div>
            </div>
            <div id="review-list"></div>
        </div>
    </div>

    <!-- Popup for images -->
    <div class="image-popup-overlay" id="imagePopup">
        <span class="popup-close" id="popupClose"></span>
        <img id="popupImage" src="" alt="Review Image">
    </div>

</div>

<!-- Bottom Fixed Buttons -->
<div class="floating-btns">
    <button class="btn-cart" onclick="buyNow()"><i class="bi bi-cart-fill"></i> Add to Cart</button>
    <button class="btn-buy" onclick="buyNow()">Buy Now</button>
</div>

<!-- Footer -->
<footer class="seofooter" style="padding-bottom: 70px;">
    <div class="footer-container">
        <div class="footer-links">
            <a href="#">Become a Seller</a> <a href="#">Advertise</a> <a href="#">Help Center</a>
        </div>
        <p class="footer-copy">© 2007–2026 <strong>Flipkart.com</strong></p>
        <div class="footer-payments"><img src="payment-method_69e7ec.svg"></div>
    </div>
</footer>

<script src="../assets/website/js/jquery.min.js"></script>
<script src="../assets/website/js/bootstrap.min.js" defer=""></script>
<script src="../data/site-settings.js?v=1785156753"></script>

<script>
// ==========================================
// 🛍️ CORE FUNCTIONALITY SCRIPTS
// ==========================================

const JSON_URL = MAIN_URL + "data.json";
let productData = null, selectedColor = "";

function getPrimaryId() {
  const urlParams = new URLSearchParams(window.location.search);
  if(urlParams.has('id')) return urlParams.get('id');
  const path = window.location.pathname.split("/");
  let idx = path.indexOf("single-products");
  if(idx !== -1 && path[idx+1]) return path[idx+1].replace('/', '');
  return "1"; 
}
const PRIMARY_ID = getPrimaryId();

function doAPICall(req, callback) {
  fetch(JSON_URL, { cache: "no-store" })
    .then(res => res.json())
    .then(data => {
      if(req.op === "get_product_details") {
        const product = data.products.find(p => String(p.id) === String(req.id) && !p.hidden);
        if (product) callback({ status: true, data: product });
        else callback({ status: false });
      }
    })
    .catch(() => callback({ status: false }));
}

function loadProductDetails(res) {
  if (res && res.status) {
    productData = res.data;
    $(".product-title").text(productData.name);
    updatePrice(productData.selling_price, productData.mrp, productData.wow_price);
    
    let realRating = productData.rating || 4.5;
    let realReviews = productData.reviews_count || 1245;
    $("#rating-value").text(realRating);
    $("#ratingcount").text(`${realReviews.toLocaleString('en-IN')} Ratings & Reviews`);

    if(productData.colors && productData.colors.length > 0) {
        renderColors(productData.colors);
        renderCarousel(productData.colors[0].images);
    }
    
    if(productData.description && productData.description.trim() !== "") {
        $("#text-description").html(productData.description);
    }
    renderDescriptionImages(productData.description_images);

    if(productData.highlights && productData.highlights.length > 0) {
        $("#highlights-container").removeClass("d-none");
        let hls = productData.highlights.map(h => `<li>${h}</li>`).join('');
        $("#product-highlights").html(hls);
    }

    if(productData.specifications && Object.keys(productData.specifications).length > 0) {
        $("#specs-container").removeClass("d-none");
        let specHtml = '<table class="spec-table"><tbody>';
        for(let key in productData.specifications) {
            let val = productData.specifications[key];
            if(typeof val === 'object' && !Array.isArray(val)) {
                for(let subKey in val) {
                    let textVal = Array.isArray(val[subKey]) ? val[subKey].join(', ') : val[subKey];
                    specHtml += `<tr><td>${subKey}</td><td>${textVal}</td></tr>`;
                }
            }
        }
        specHtml += '</tbody></table>';
        $("#product-specs").html(specHtml);
    }
  } else if (!res) {
    doAPICall({ op: "get_product_details", id: PRIMARY_ID }, loadProductDetails);
  } else {
    if(PRIMARY_ID !== "1") doAPICall({ op: "get_product_details", id: "1" }, loadProductDetails);
    else alert("Product not found");
  }
}

function renderColors(colors) {
  const list = $(".color-list").empty();
  if(colors.length <= 1) $(".color-div").hide(); 
  
  colors.forEach((c, i) => {
    const div = $(`<div class="color-item ${i === 0 ? "active" : ""}">
      <img src="${c.color_img}"><p>${c.color_name}</p></div>`);
      
    div.click(() => {
      $(".color-item").removeClass("active"); div.addClass("active");
      selectedColor = c.color_name; renderCarousel(c.images);
    });
    list.append(div);
    if (i === 0) selectedColor = c.color_name;
  });
}

function renderCarousel(images) {
  const inner = $(".carousel-inner").empty(), ind = $(".carousel-indicators").empty();
  images.forEach((img, i) => {
    inner.append(`<div class="carousel-item ${i === 0 ? "active" : ""}"><img src="${img}" class="d-block w-100"></div>`);
    ind.append(`<button type="button" data-bs-target="#sliderX" data-bs-slide-to="${i}" class="${i === 0 ? "active" : ""}"></button>`);
  });
}

function renderDescriptionImages(images) {
  const desc = $("#description-images").empty();
  if (!images || !images.length) return;
  images.forEach(img => desc.append(`<img src="${img}" loading="lazy" style="width:100%; margin-bottom:5px;">`));
}

function updatePrice(selling, mrp, wow_price) {
  function formatINR(amt) { return Number(amt).toLocaleString("en-IN"); }
  $(".price").text("₹" + formatINR(selling));
  $(".mrp").text("₹" + formatINR(mrp));
  wow_price = wow_price || (selling - 100);
  $(".wow_price").text("₹" + formatINR(wow_price));
  let d = mrp > 0 ? (100 - (selling * 100 / mrp)).toFixed(0) : 0;
  $(".discount").text((d == 100 ? 99 : d) + "% off");
}

function isAddressRequired(settings) {
  const v = settings && settings.address_required;
  return !(v === false || v === 0 || v === "0" || v === "false");
}

async function loadSiteSettings() {
  try {
    const res = await fetch(MAIN_URL + "data/settings.json?t=" + Date.now(), { cache: "no-store" });
    if (res.ok) {
      const s = await res.json();
      if (s && typeof s === "object") {
        window.FK_SITE_SETTINGS = Object.assign({}, window.FK_SITE_SETTINGS || {}, s);
      }
    }
  } catch (e) {}
  return window.FK_SITE_SETTINGS || {};
}

async function buyNow() {
  if (!productData) return;
  const color = productData.colors.find(c => c.color_name === selectedColor) || productData.colors[0];
  const variant = { name: productData.name, color: selectedColor, mrp: productData.mrp, selling_price: productData.selling_price, img1: color.images[0] };
  localStorage.setItem("selected_verient", JSON.stringify(variant));
  const settings = await loadSiteSettings();
  const needAddress = isAddressRequired(settings);
  window.location.href = MAIN_URL + (needAddress ? "address/index.php" : "cart/");
}

function startCountdown(min, sec) {
  let t = min * 60 + sec;
  const el = document.getElementById("timer");
  if(!el) return;
  setInterval(() => {
    const m = Math.floor(t / 60), s = t % 60;
    el.textContent = `${m}m ${s}s`;
    if (--t < 0) t = min * 60 + sec;
  }, 1000);
}

function openReviewImage(imgSrc) {
    const popup = document.getElementById("imagePopup");
    const popupImg = document.getElementById("popupImage");
    if(popup && popupImg) { popupImg.src = imgSrc; popup.style.display = "flex"; }
}

function loadReviews() {
  const section = document.getElementById("reviewsSection"), loader = document.getElementById("review-loader"), list = document.getElementById("review-list");
  if(!section) return; loader.style.display = "flex";
  
  fetch(JSON_URL, { cache: "no-store" }).then(res => res.json()).then(data => {
      const allReviews = data.reviews || [];
      const reviewsData = Array.isArray(allReviews) ? allReviews.filter(r => String(r.product_id) === String(PRIMARY_ID)) : [];
      if (!reviewsData || reviewsData.length === 0) { section.style.display = "none"; return; }
      loader.style.display = "none";

      reviewsData.forEach((review, i) => {
        let starsHTML = ""; const rVal = review.rating || 5, full = Math.floor(rVal);
        for (let j = 0; j < full; j++) starsHTML += '<i class="bi bi-star-fill" style="color:#26a541;"></i>';
        while (starsHTML.match(/bi-star/g)?.length < 5) starsHTML += '<i class="bi bi-star" style="color:#ccc;"></i>';
        const authorName = review.author || review.customer_name || 'Flipkart Customer', rText = review.text || review.comment || '', rTitle = review.title || '';
        
        let imagesHTML = "";
        if (review.images && Array.isArray(review.images) && review.images.length > 0) {
            imagesHTML = `<div class="review-images-scroll">`;
            review.images.forEach(img => { imagesHTML += `<div class="review-thumb-box" onclick="openReviewImage('${img}')"><img src="${img}" loading="lazy"></div>`; });
            imagesHTML += `</div>`;
        }
        const div = document.createElement("div");
        div.className = "mb-3 pb-3"; div.style.borderBottom = "1px solid #f0f0f0";
        div.innerHTML = `
          <div class="d-flex align-items-center mb-2 gap-2"><div style="background:#26a541; padding:2px 6px; border-radius:4px; color:#fff; font-size:12px; font-weight:bold;">${rVal} <i class="bi bi-star-fill" style="font-size:9px;"></i></div><span style="font-size:14px; font-weight:600; color:#212121;">${rTitle}</span></div>
          <p style="font-size:14px; margin-bottom:8px; color:#212121; line-height:1.4;">${rText}</p>${imagesHTML}
          <div style="display:flex; align-items:center; gap:8px;"><p style="font-size:12px; color:#878787; margin:0; font-weight:500;">${authorName}</p><i class="bi bi-check-circle-fill" style="color:#878787; font-size:11px;"></i><span style="font-size:12px; color:#878787;">Certified Buyer</span></div>`;
        list.appendChild(div);
      });
    }).catch(err => { section.style.display = "none"; });
}

function loadSimilarProducts() {
  fetch(JSON_URL, { cache: "no-store" }).then(res => res.json()).then(data => {
      const similar = data.products.filter(p => p.id != PRIMARY_ID).sort(() => 0.5 - Math.random()).slice(0, 10);
      const scroll = document.getElementById("similar-scroll");
      if(!scroll) return; scroll.innerHTML = "";
      similar.forEach((p) => {
        const mrp = Number(p.mrp), sell = Number(p.selling_price), discount = mrp ? Math.round(((mrp - sell) / mrp) * 100) : 0, pRating = p.rating || 4.5;
        let starsHTML = "";
        for (let j = 0; j < Math.floor(pRating); j++) starsHTML += '<i class="bi bi-star-fill" style="color:#26a541;"></i>';
        if (pRating % 1 !== 0) starsHTML += '<i class="bi bi-star-half" style="color:#26a541;"></i>';
        const div = document.createElement("div"); div.className = "similar-card";
        div.innerHTML = `
          <a href="${MAIN_URL}products/index.php?id=${p.id}" style="text-decoration:none;color:inherit;display:flex;flex-direction:column;height:100%;">
            <div style="height:140px; padding:10px;"><img src="${p.img1}" class="sim-img"></div>
            <div style="padding:8px; display:flex; flex-direction:column; flex:1;">
              <div style="height:34px;overflow:hidden;font-size:12px;line-height:1.4;margin-bottom:6px;">${p.name}</div>
              <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-bottom:4px;">
                <span style="color:#388e3c;font-weight:700;font-size:12px;">${discount}% off</span><span style="text-decoration:line-through;color:#878787;font-size:12px;">₹${mrp.toLocaleString("en-IN")}</span><span style="font-weight:700;font-size:15px;color:#212121;">₹${sell.toLocaleString("en-IN")}</span>
              </div>
              <div style="margin-top:auto; display:flex; justify-content:space-between; align-items:center;">
                  <div style="display:flex;align-items:center;gap:4px;"><div style="display:flex;font-size:10px;">${starsHTML}</div><span style="font-size:11px;color:#878787;">(${pRating})</span></div>
                  <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png" style="height:14px;">
              </div>
            </div></a>`;
        scroll.appendChild(div);
      });
  });
}

// ========== HIDE LOADER AFTER PAGE LOADS ==========
function hideProductLoader() {
    var loader = document.getElementById("productLoader");
    if (loader) {
        loader.classList.add("is-hidden");
        document.body.classList.remove("loading-active");
        setTimeout(function() {
            if (loader && loader.parentNode) loader.parentNode.removeChild(loader);
        }, 400);
    }
}

document.addEventListener("DOMContentLoaded", () => {
  loadProductDetails(); loadSimilarProducts(); loadReviews();
  const deliveryDate = new Date(); deliveryDate.setDate(deliveryDate.getDate() + 2);
  let dd = document.getElementById("delivery-date"); if(dd) dd.innerText = deliveryDate.toLocaleString('en-US', { day: "numeric", month: "short", weekday: "short" });
  startCountdown(15, 10);
  document.getElementById("popupClose")?.addEventListener("click", () => { document.getElementById("imagePopup").style.display = "none"; });
  
  // Hide loader after everything is rendered
  setTimeout(hideProductLoader, 500);
});

// Fallback: hide loader even if DOMContentLoaded already fired
window.addEventListener('load', function() {
    setTimeout(hideProductLoader, 300);
});
</script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"c6604ce2f3ff491e85b417450e314113","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"0b8e22d3a4974dc3aa78061e2476c9a7","r":1}' crossorigin="anonymous"></script>
</body>
</html>
<!-- SALT_1f55af930ef5632e9c4bd21c0f06e192 -->